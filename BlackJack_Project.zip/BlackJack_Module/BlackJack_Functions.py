from BlackJack_Module.BlackJack_Classes import *

def hand_converter(hand):
    value_mapping = {'A':11,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'Jack':10,'Queen':10,'King':10}
    card_values = ['A','2','3','4','5','6','7','8','9','10','Jack','Queen','King']
    hand_value = 0
    card_count = 0

    for card in card_values:
        if (card in hand):
            card_count = hand.count(card)
            hand_value += value_mapping[card]*card_count
    return hand_value

def winner():
    print("\nCongratulations " + player1.name + "! You have won this round!")
    player1.spoils(player1.wager)
    house.losses()
    print("\n" + player1.name + "'s funds: " + str(player1.funds))


def loser():
    print("\nSorry " + player1.name + "....you have lost this round!")
    player1.losses()
    house.spoils(player1.wager)
    print("\n" + player1.name + "'s funds: " + str(player1.funds))


def push():
    print("\nPUSH!")
    player1.draw(player1.wager)
    print(player1.name + "'s funds: " + str(player1.funds))


def keep_playing(play):
    #    user_response = input("\nWould you like to keep playing? [Enter either 'Yes' or 'No']: ")
    #    while user_response.lower() != 'yes' and user_response.lower() != 'no':
    #        user_response = input("\nYou entered an incorrect value. Please enter either 'Yes' or 'No': ")
    #    else:
    #        if 'y' in user_response.lower():
    #            play = True
    #        else:
    #            play = False
    #        return play
    user_response = input("\nWould you like to keep playing? [Enter either 'Yes' or 'No']: ")

    if 'yes' in user_response.lower():
        play = True
    elif 'no' in user_response.lower():
        play = False
    else:
        print("\nYou have entered an incorrect value.")
        keep_playing(play)

    return play
