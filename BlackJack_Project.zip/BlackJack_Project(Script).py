import random
from BlackJack_Module.BlackJack_Classes import *
from BlackJack_Module.BlackJack_Functions import *


def hand_converter(hand):
    value_mapping = {'A':11,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'Jack':10,'Queen':10,'King':10}
    card_values = ['A','2','3','4','5','6','7','8','9','10','Jack','Queen','King']
    hand_value = 0
    card_count = 0

    for card in card_values:
        if (card in hand):
            card_count = hand.count(card)
            hand_value += value_mapping[card]*card_count
    return hand_value

def winner():
    print("\nCongratulations " + player1.name + "! You have won this round!")
    player1.spoils(player1.wager)
    house.losses()
    print("\n" + player1.name + "'s funds: " + str(player1.funds))

def loser():
    print("\nSorry " + player1.name + "....you have lost this round!")
    player1.losses()
    house.spoils(player1.wager)
    print("\n" + player1.name + "'s funds: " + str(player1.funds))
 
def push():
    print("\nPUSH!")
    player1.draw(player1.wager)        
    print(player1.name + "'s funds: " + str(player1.funds))

def keep_playing(play):
#    user_response = input("\nWould you like to keep playing? [Enter either 'Yes' or 'No']: ")
#    while user_response.lower() != 'yes' and user_response.lower() != 'no':
#        user_response = input("\nYou entered an incorrect value. Please enter either 'Yes' or 'No': ")
#    else:    
#        if 'y' in user_response.lower():
#            play = True
#        else:
#            play = False
#        return play
    user_response = input("\nWould you like to keep playing? [Enter either 'Yes' or 'No']: ")
    
    if 'yes' in user_response.lower():
        play = True
    elif 'no' in user_response.lower():
        play = False
    else:
        print("\nYou have entered an incorrect value.")
        keep_playing(play)
        
    return play
    
print("Welcome to Black Jack!")

user_response = ""
play = True
player1 = Player()
house = Dealer(1000000)

while play == True and player1.funds > 0:
    CardDeck = Deck()
    while True:
        house.reset()
        player1.reset()
        player1.bet()
        house.original_dealer_hand()
        player1.original_player_hand()
        
        player1.value_of_hand()
        
        if player1.value_of_hand() == 21:
            winner()
            play = keep_playing(play)
            break

        while (player1.action != "stay"):
            
            if player1.value_of_hand() > 21:
                loser()
                break
            else:
                player1.play()

        if player1.value > 21:
            play = keep_playing(play)
            break

        while house.value_of_hand() < player1.value:
            house.play()

        if (player1.value == house.value):
            push()
            play = keep_playing(play)
            break        
        
        elif (player1.value > house.value) or (house.value > 21):
            winner()
            play = keep_playing(play)
            break

        else:
            loser()
            play = keep_playing(play)
            break
else:
    if player1.funds <= 0:
        print("\nYou ran out of funds!")
    else:
        print("\nThank you for playing!")

#savinggg
